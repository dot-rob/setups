#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
for theme in nord-dark nord-light qogir-dark qogir-light papirus-dark papirus-light; do
  echo "Installing $theme..."
  "$SCRIPT_DIR/themes/$theme/install.sh"
done
echo
echo "All six companion theme sets are installed."
