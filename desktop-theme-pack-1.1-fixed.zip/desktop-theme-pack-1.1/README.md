# Desktop Companion Theme Pack 1.1

Six matching application theme sets for light and dark Linux desktops:

- Nord Dark
- Nord Light
- Qogir Dark
- Qogir Light
- Papirus Dark
- Papirus Light

Each set includes themes for:

- Geany
- XFCE4 Terminal
- Mousepad / GtkSourceView 3 and 4
- Rofi
- Tilix

## Install everything

```bash
./install-all.sh
```

## Install only one theme

Run the `install.sh` inside the desired folder under `themes/`.

All six variants use distinct filenames and display names, so they can coexist.
