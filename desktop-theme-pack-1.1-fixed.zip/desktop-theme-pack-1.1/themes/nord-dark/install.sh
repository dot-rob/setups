#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
THEME="nord-dark"

mkdir -p   "$HOME/.config/geany/colorschemes"   "$HOME/.local/share/xfce4/terminal/colorschemes"   "$HOME/.local/share/gtksourceview-4/styles"   "$HOME/.local/share/gtksourceview-3.0/styles"   "$HOME/.config/rofi/themes"   "$HOME/.config/tilix/schemes"

install -m 0644 "$SCRIPT_DIR/$THEME.conf"  "$HOME/.config/geany/colorschemes/$THEME.conf"
install -m 0644 "$SCRIPT_DIR/$THEME.theme" "$HOME/.local/share/xfce4/terminal/colorschemes/$THEME.theme"
install -m 0644 "$SCRIPT_DIR/$THEME.xml"   "$HOME/.local/share/gtksourceview-4/styles/$THEME.xml"
install -m 0644 "$SCRIPT_DIR/$THEME.xml"   "$HOME/.local/share/gtksourceview-3.0/styles/$THEME.xml"
install -m 0644 "$SCRIPT_DIR/$THEME.rasi"  "$HOME/.config/rofi/themes/$THEME.rasi"
install -m 0644 "$SCRIPT_DIR/$THEME.json"  "$HOME/.config/tilix/schemes/$THEME.json"

echo "Installed $THEME companion themes. Restart open applications if needed."
