# Papirus Dark

Papirus-inspired companion application theme using the official Papirus default folder blue `#5294E2` and darker companion blue `#4877B1`.

Includes Geany, XFCE4 Terminal, Mousepad/GtkSourceView, Rofi, and Tilix.
