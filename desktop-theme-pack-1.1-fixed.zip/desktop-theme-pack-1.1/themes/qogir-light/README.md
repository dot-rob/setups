# Qogir Light companion themes for XFCE/Debian

Light companion color schemes for Geany, XFCE4 Terminal, Mousepad/GtkSourceView, Rofi, and Tilix. These are designed to pair with a light desktop theme while retaining the Qogir visual character.

## Install

Run `./install.sh`, then select the **Qogir Light** scheme in each application.

## Files

- `qogir-light.conf` — Geany
- `qogir-light.theme` — XFCE4 Terminal
- `qogir-light.xml` — Mousepad / GtkSourceView
- `qogir-light.rasi` — Rofi
- `qogir-light.json` — Tilix
