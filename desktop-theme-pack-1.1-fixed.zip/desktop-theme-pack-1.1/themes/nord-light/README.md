# Nord Light companion themes for XFCE/Debian

Light companion color schemes for Geany, XFCE4 Terminal, Mousepad/GtkSourceView, Rofi, and Tilix. These are designed to pair with a light desktop theme while retaining the Nord visual character.

## Install

Run `./install.sh`, then select the **Nord Light** scheme in each application.

## Files

- `nord-light.conf` — Geany
- `nord-light.theme` — XFCE4 Terminal
- `nord-light.xml` — Mousepad / GtkSourceView
- `nord-light.rasi` — Rofi
- `nord-light.json` — Tilix
