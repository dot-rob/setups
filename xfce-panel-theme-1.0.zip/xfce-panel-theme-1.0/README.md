# XFCE Panel Theme 1.0

A focused GTK 3 stylesheet for the XFCE panel. It provides a balanced, Nord-inspired panel appearance while allowing the active GTK theme—such as Qogir or Nordic—to continue styling applications and menus.

## Compatibility

- XFCE 4.18 or newer
- GTK 3.20 or newer
- Tested by static selector and specificity review for Qogir and Nordic GTK themes
- Designed for common plugins including Tasklist, Whisker Menu, Clock, Status Notifier, Weather, CPU Graph, Netload, and GenMon

## Installation

Back up any existing GTK 3 override first:

```bash
mkdir -p ~/.config/gtk-3.0
cp -a ~/.config/gtk-3.0/gtk.css ~/.config/gtk-3.0/gtk.css.backup 2>/dev/null || true
cp gtk-3.0/gtk.css ~/.config/gtk-3.0/gtk.css
xfce4-panel -r
```

Log out and back in if a plugin does not immediately reload its styling.

## Design Decisions

- Nearly all selectors are scoped beneath `.xfce4-panel`.
- GTK menus are intentionally not styled, so panel context menus and application menus remain consistent with the active GTK theme.
- Weather, CPU Graph, and Netload retain their plugin-controlled graph and data colors.
- GenMon receives limited styling through its documented panel classes.
- Symbolic color names use the `xfcep_` prefix to avoid collisions with the active GTK theme.
- Tooltip styling is global by design. Remove the final `TOOLTIPS` section from `gtk.css` to let the active GTK theme style all tooltips instead.

## Removing the Theme

Restore the backup:

```bash
mv ~/.config/gtk-3.0/gtk.css.backup ~/.config/gtk-3.0/gtk.css
xfce4-panel -r
```

Or remove the override entirely:

```bash
rm ~/.config/gtk-3.0/gtk.css
xfce4-panel -r
```

## Testing Notes

Version 1.0 intentionally freezes the visual behavior of 0.9.1. Future changes should be based on observed issues during normal use, especially with vertical panels, multi-row panels, autohide, multiple monitors, unusual panel heights, and less-common plugins.

## Screenshots

The `screenshots` directory is reserved for reference images from Qogir and Nordic installations. No screenshots are bundled in this release.
