# Changelog

## 1.0 — 2026-07-19

- Promoted the stable 0.9.1 stylesheet to the first production release.
- Added release metadata, compatibility targets, installation instructions, and scope documentation.
- Documented that menus intentionally inherit the active GTK theme.
- Documented global tooltip styling as the sole intentional non-panel-scoped exception.
- Added README, changelog, packaged install layout, and a screenshots placeholder.
- Made no intentional visual or behavioral changes from 0.9.1.

## 0.9.1

- Removed confirmed redundant selectors and unused symbolic colors.
- Preserved defensive Qogir and Nordic state overrides.

## 0.9

- Stopped styling GTK menus so panel and application menus use the active GTK theme consistently.
- Retained panel-owned popover and embedded-control styling.

## Earlier Development

- Scoped panel styling to XFCE panel widgets.
- Replaced unsupported eight-digit hexadecimal colors with GTK 3-compatible six-digit values.
- Normalized hover, checked, active, and disabled states.
- Normalized panel, plugin, button, tasklist, menu-surface, and control spacing.
- Added safe support for common plugins without overriding CPU Graph or Netload data colors.
- Namespaced symbolic colors to prevent collisions with Qogir, Nordic, and other GTK themes.
