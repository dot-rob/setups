# Screenshots

Add representative screenshots here after extended testing, ideally including:

- Qogir with a horizontal panel
- Nordic with a horizontal panel
- A vertical or multi-row panel
- Whisker Menu, Weather, GenMon, Netload, and CPU Graph in normal use
